package assignment.five

import org.apache.log4j.{Level, Logger}
import org.apache.sedona.viz.core.Serde.SedonaVizKryoRegistrator
import org.apache.sedona.sql.utils.{Adapter, SedonaSQLRegistrator}
import org.apache.sedona.viz.sql.utils.SedonaVizRegistrator
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.SparkSession

import java.io.File
import scala.reflect.io.Directory

object AssignmentFive extends App {

  Logger.getLogger("org").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)

  var sparkSession:SparkSession = SparkSession.builder().
    config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    .config("spark.serializer",classOf[KryoSerializer].getName).
    config("spark.kryo.registrator", classOf[SedonaVizKryoRegistrator].getName).
    master("local[*]")
    .appName("lastassignment").getOrCreate()

  SedonaSQLRegistrator.registerAll(sparkSession)
  SedonaVizRegistrator.registerAll(sparkSession)

  val resourseFolder = System.getProperty("user.dir")+"/src/test/resources/"
  val csvPolygonInputLocation = resourseFolder + "testenvelope.csv"
  val csvPointInputLocation = resourseFolder + "testpoint.csv"
  val firstpointdata = resourseFolder + "outputdata/firstpointdata"
  val firstpolydata = resourseFolder + "outputdata/firstpolygondata"

  println("Q2.1")
  firstPointQuery()
  println("Q2.2")
  secondPointQuery()
  println("Q2.3")
  firstPloygonQuery()
  println("Q2.4")
  secondPolygonQuery()
  println("Q2.5")
  JoinQuery()

  println("Assignment Five Done!!!")

  def firstPointQuery(): Unit = {
    //Read the given testpoint.csv file in csv format and write in delta format and save named firstpointdata
    val directory = new Directory(new File(firstpointdata))
    directory.deleteRecursively()

    val df = sparkSession.read.format("csv").option("header", "false").option("delimiter", ",").load(csvPointInputLocation)
    df.write.format("delta").mode("overwrite").save(firstpointdata)

    var read_points = sparkSession.read.parquet(firstpointdata)
    read_points = read_points.toDF()
    read_points.createOrReplaceTempView("pointsdata")
    read_points = sparkSession.sql("SELECT _c0, _c1 FROM pointsdata " +
      "WHERE CAST(pointsdata._c0 as Decimal(24,20)) > 500 " +
      "and CAST(pointsdata._c1 as Decimal(24,20)) > 500")
    //read_points.show()
    read_points.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(firstpointdata)
  }

  def secondPointQuery(): Unit = {
    //Read the firstpointdata in delta format. Print the total count of the points.
    print("Total Count of points whose attributes are all larger than 500 = ")
    println(sparkSession.read.format("delta").load(firstpointdata).count());
  }

  def firstPloygonQuery(): Unit = {
    //Read the given testenvelope.csv in csv format and write in delta format and save it named firstpolydata
    val directory = new Directory(new File(firstpolydata))
    directory.deleteRecursively()

    val df = sparkSession.read.format("csv").option("header", "false").option("delimiter", ",").load(csvPolygonInputLocation)
    df.write.format("delta").mode("overwrite").save(firstpolydata)

    var read_poly = sparkSession.read.parquet(firstpolydata)
    read_poly = read_poly.toDF()
    read_poly.createOrReplaceTempView("polydata")
    read_poly = sparkSession.sql("SELECT _c0, _c1, _c2, _c3 FROM polydata " +
      "WHERE CAST(polydata._c0 as Decimal(24,20)) > 900 " +
      "and CAST(polydata._c1 as Decimal(24,20)) > 900 " +
      "and CAST(polydata._c2 as Decimal(24,20)) > 900 " +
      "and CAST(polydata._c3 as Decimal(24,20)) > 900")
    //read_poly.show()
    read_poly.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(firstpolydata)
  }

  def secondPolygonQuery(): Unit = {
    //Read the firstpolydata in delta format. Print the total count of the polygon
    print("Total Count of polygons whose attributes are all larger than 900 = ")
    println(sparkSession.read.format("delta").load(firstpolydata).count());
  }

  def JoinQuery(): Unit = {
    //Read the firstpointdata in delta format and find the total count for point pairs where distance between the points within a pair is less than 2.
    var read_points = sparkSession.read.format("delta").load(firstpointdata)
    read_points = read_points.toDF()
    read_points.createOrReplaceTempView("read_points")
    read_points = sparkSession.sql("SELECT ST_Point(CAST(read_points._c0 as Decimal(7,2)), "+
      "CAST(read_points._c1 as Decimal(7,2))) as point "+
      "FROM read_points")
    read_points.createOrReplaceTempView("points_view")

    var read_polygons = sparkSession.read.format("delta").load(firstpolydata)
    read_polygons = read_polygons.toDF()
    read_polygons.createOrReplaceTempView("read_polygons")
    read_polygons = sparkSession.sql("SELECT ST_PolygonFromEnvelope(CAST(read_polygons._c0 as Decimal(7,2)), " +
      "CAST(read_polygons._c1 as Decimal(7,2)), " +
      "CAST(read_polygons._c2 as Decimal(7,2)), " +
      "CAST(read_polygons._c3 as Decimal(7,2))) as polygon " +
      "FROM read_polygons")
    read_polygons.createOrReplaceTempView("polygon_view")

    var temp_join = sparkSession.sql("SELECT points_view.point as point " +
      "FROM points_view, polygon_view " +
      "WHERE ST_Contains(polygon_view.polygon, points_view.point)")
    temp_join.createOrReplaceTempView("point_polygon_join")

    var joinPoints = sparkSession.sql("SELECT * FROM " +
      "point_polygon_join p1 join point_polygon_join p2 " +
      "WHERE p1.point != p2.point " +
      "AND ST_Distance(p1.point, p2.point) < 2")
    println(joinPoints.count()/2)
  }
}